# OpenClaw 常用群聊 ID
# 保存时间: 2026-03-05

# OpenClaw 讨论群
openclaw_discussion_chat_id=oc_40efcf271da2a542291ab9b83d2eea97
