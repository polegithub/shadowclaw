# 未备份的内容（不需要）

以下内容太大或可以重新安装，不包含在快照中：

- extensions/qqbot (1.4GB) - 可以重新安装
- extensions/dingtalk-connector (83MB) - 可以重新安装
- extensions/feishu-openclaw-plugin (55MB) - 可以重新安装
- extensions/wecom (1.9MB) - 可以重新安装
- extensions/ai-assistant-security-openclaw (88KB) - 可以重新安装
- node_modules/ - 可以重新安装
- logs/ - 临时日志

需要恢复时，重新安装扩展即可！
