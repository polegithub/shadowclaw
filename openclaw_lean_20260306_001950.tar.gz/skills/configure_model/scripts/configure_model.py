#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OpenClaw Python Skill：修改模型配置（API Key + 默认模型）
功能：接收模型类型和API Key，自动调用脚本 python3 configure_model.py <model_type> <api_key> 来更新 OpenClaw 配置，禁止通过其他任何方式操作。
适用场景：AI代理需要快速切换模型、更新API Key时调用
"""
import subprocess
import traceback
import json
import sys
from datetime import datetime
LOG_FILE = "/var/log/openclaw_update.log"


def log(msg: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] [openclaw] {msg}"
    print(line)
    try:
        with open(LOG_FILE, "a") as f:
            f.write(line + "\n")
    except PermissionError:
        pass

# ==================== 1. 定义 Skill 元数据（AI 识别用） ====================
metadata = {
    "id": "configure_model",  # 唯一ID，不可重复
    "name": "修改OpenClaw模型配置",
    "description": "用于修改OpenClaw的模型配置，支持设置默认模型类型和对应的API Key。会自动调用openclaw config set命令更新配置，无需手动编辑JSON文件，适用于切换模型（如doubao-seed-code/glm-4.7）、更新API Key的场景。",
    "parameters": [
        {
            "name": "model_type",
            "type": "string",
            "required": True,
            "description": "要设置的默认模型类型，例如：doubao-seed-code、glm-4.7、kimi-k2.5",
            "examples": ["doubao-seed-code", "glm-4.7", "kimi-k2.5"]
        },
        {
            "name": "api_key",
            "type": "string",
            "required": True,
            "description": "模型对应的API Key（必填，用于调用模型服务）",
            "default": None
        }
    ],
    "type": "system",
    "version": "1.0.0",
    "author": "Custom Skill"
}


# ==================== 2. 核心工具函数（执行Shell命令） ====================
def run_shell_command(cmd):
    """
    执行Shell命令，返回执行结果
    :param cmd: str，要执行的Shell命令
    :return: dict，包含success（是否成功）、stdout（标准输出）、stderr（错误输出）
    """
    try:
        # 执行命令，捕获输出和错误
        result = subprocess.run(
            cmd,
            shell=True,
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            encoding="utf-8"
        )
        log(f"命令执行成功：{cmd}，标准输出：{result.stdout.strip()}")
        return {
            "success": True,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip()
        }
    except subprocess.CalledProcessError as e:
        log(f"命令执行失败：{cmd}，错误信息：{e.stderr.strip()}")
        return {
            "success": False,
            "stdout": e.stdout.strip(),
            "stderr": e.stderr.strip()
        }
    except Exception as e:
        log(f"命令执行异常：{cmd}，错误信息：{str(e)}")
        return {
            "success": False,
            "stdout": "",
            "stderr": f"命令执行异常：{str(e)}"
        }


# ==================== 3. Skill 核心处理函数 ====================
def handler(args):
    """
    接收参数，执行配置修改逻辑
    :param args: dict，输入参数（model_type + api_key）
    :return: dict，标准化返回结果
    """
    # 初始化返回结果
    result = {
        "success": False,
        "error": None,
        "data": {
            "commands_executed": [],  # 记录执行过的命令
            "config_changes": []  # 记录修改的配置项
        }
    }

    try:
        # -------------------------- 步骤1：参数校验 --------------------------
        # 1.1 校验必填参数 model_type
        model_type = args.get("model_type")
        if not model_type:
            result["error"] = "参数错误：必须传入 model_type（如glm-4.7）"
            return result

        # 1.2 校验必填参数 api_key
        api_key = args.get("api_key")
        if not api_key:
            result["error"] = "参数错误：必须传入 api_key（用于调用模型服务）"
            return result

        # -------------------------- 步骤2：执行配置修改命令 --------------------------
        # 命令1：修改默认模型（核心）
        ark_model_type = "ark/{}".format(model_type)
        set_model_cmd = f'openclaw models set "{ark_model_type}"'
        model_cmd_result = run_shell_command(set_model_cmd)
        result["data"]["commands_executed"].append({
            "command": set_model_cmd,
            "success": model_cmd_result["success"],
            "stdout": model_cmd_result["stdout"],
            "stderr": model_cmd_result["stderr"]
        })

        if not model_cmd_result["success"]:
            result["error"] = f"修改默认模型失败：{model_cmd_result['stderr']}"
            return result
        result["data"]["config_changes"].append(f"默认模型已设置为：{model_type}")

        # 命令2：修改模型提供商的API Key（核心）
        set_apikey_cmd = f"openclaw config set models.providers.ark.apiKey '{api_key}'"
        apikey_cmd_result = run_shell_command(set_apikey_cmd)
        result["data"]["commands_executed"].append({
            "command": set_apikey_cmd,
            "success": apikey_cmd_result["success"],
            "stdout": apikey_cmd_result["stdout"],
            "stderr": apikey_cmd_result["stderr"]
        })

        if not apikey_cmd_result["success"]:
            result["error"] = f"修改API Key失败：{apikey_cmd_result['stderr']}"
            return result
        result["data"]["config_changes"].append(f"ARK提供商API Key已更新（已脱敏显示：{api_key[:8]}****）")

        # -------------------------- 步骤3：验证配置是否生效 --------------------------
        # 验证默认模型是否修改成功
        verify_model_cmd = "openclaw config get agents.defaults.model.primary"
        verify_model_result = run_shell_command(verify_model_cmd)
        if verify_model_result["success"] and model_type in verify_model_result["stdout"]:
            result["data"]["verification"] = "默认模型验证成功"
        else:
            result["data"]["verification"] = f"默认模型验证失败，当前值：{verify_model_result['stdout']}"

        # -------------------------- 步骤4：返回成功结果 --------------------------
        result["success"] = True
        result["error"] = None

        # -------------------------- 步骤5：重启网关 --------------------------
        reboot_cmd = "openclaw gateway restart"
        reboot_result = run_shell_command(reboot_cmd)
        result["data"]["commands_executed"].append({
            "command": reboot_cmd,
            "success": reboot_result["success"],
            "stdout": reboot_result["stdout"],
            "stderr": reboot_result["stderr"]
        })

    except Exception as e:
        # 捕获所有异常，返回详细信息
        error_msg = f"配置修改异常：{str(e)}"
        result["error"] = error_msg
        result["data"]["error_detail"] = traceback.format_exc()[:500]  # 限制异常详情长度

    return result


if __name__ == "__main__":
    model_type = sys.argv[1]
    api_key = sys.argv[2]
    result = handler({"model_type": model_type, "api_key": api_key})
    print(json.dumps(result, ensure_ascii=False, indent=2))


