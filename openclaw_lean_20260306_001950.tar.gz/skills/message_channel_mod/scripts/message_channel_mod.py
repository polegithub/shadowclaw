#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OpenClaw Python Skill：配置飞书/钉钉消息渠道
功能：接收飞书/钉钉的密钥信息，自动调用python脚本 python3 message_channel_mod.py <channel_type> <channel_appId> <channel_appSecret> 来修改 OpenClaw 配置，禁止通过其他方式修改配置。
适用场景：AI代理需要快速配置飞书/钉钉消息推送渠道时调用
"""
import subprocess
import traceback
import json
import sys
from datetime import datetime

LOG_FILE = "/var/log/openclaw_update.log"


def log(msg: str):
    """日志记录函数：输出到控制台并写入日志文件"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] [openclaw-channel] {msg}"
    print(line)
    try:
        with open(LOG_FILE, "a") as f:
            f.write(line + "\n")
    except PermissionError:
        log("警告：无日志文件写入权限，仅输出到控制台")
    except FileNotFoundError:
        log("警告：日志目录不存在，仅输出到控制台")


# ==================== 1. 定义 Skill 元数据（AI 识别用） ====================
metadata = {
    "id": "message_channel_mod",  # 唯一ID，不可重复
    "name": "配置OpenClaw消息渠道",
    "description": "用于配置OpenClaw的飞书/钉钉消息渠道，支持设置飞书（feishu_appId/feishu_appSecret）或钉钉（dingtalk_clientId/dingtalk_clientSecret）密钥信息。会自动调用openclaw config set命令更新配置，无需手动编辑JSON文件，适用于快速配置消息推送渠道的场景。",
    "parameters": [
        {
            "name": "channel_type",
            "type": "string",
            "required": True,
            "description": "要配置的消息渠道类型，仅支持feishu（飞书）或dingtalk（钉钉）",
            "examples": ["feishu", "dingtalk"]
        },
        {
            "name": "channel_appId",
            "type": "string",
            "required": True,
            "description": "消息渠道应用ID，必填",
            "default": None
        },
        {
            "name": "channel_appSecret",
            "type": "string",
            "required": True,
            "description": "消息渠道应用密钥，必填",
            "default": None
        }
    ],
    "type": "system",
    "version": "1.0.0",
    "author": "Custom Skill"
}


# ==================== 2. 核心工具函数（执行Shell命令） ====================
def run_shell_command(cmd):
    """
    执行Shell命令，返回执行结果
    :param cmd: str，要执行的Shell命令
    :return: dict，包含success（是否成功）、stdout（标准输出）、stderr（错误输出）
    """
    try:
        # 执行命令，捕获输出和错误
        result = subprocess.run(
            cmd,
            shell=True,
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            encoding="utf-8"
        )
        log(f"命令执行成功：{cmd}，标准输出：{result.stdout.strip()}")
        return {
            "success": True,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip()
        }
    except subprocess.CalledProcessError as e:
        log(f"命令执行失败：{cmd}，错误信息：{e.stderr.strip()}")
        return {
            "success": False,
            "stdout": e.stdout.strip(),
            "stderr": e.stderr.strip()
        }
    except Exception as e:
        log(f"命令执行异常：{cmd}，错误信息：{str(e)}")
        return {
            "success": False,
            "stdout": "",
            "stderr": f"命令执行异常：{str(e)}"
        }


# ==================== 3. Skill 核心处理函数 ====================
def handler(args):
    """
    接收参数，执行消息渠道配置逻辑
    :param args: dict，输入参数（channel_type + 对应密钥）
    :return: dict，标准化返回结果
    """
    # 初始化返回结果
    result = {
        "success": False,
        "error": None,
        "data": {
            "commands_executed": [],  # 记录执行过的命令
            "config_changes": []  # 记录修改的配置项
        }
    }

    try:
        # -------------------------- 步骤1：参数校验 --------------------------
        # 1.1 校验渠道类型
        channel_type = args.get("channel_type")
        if not channel_type or channel_type not in ["feishu", "dingtalk"]:
            result["error"] = "参数错误：channel_type必须为feishu（飞书）或dingtalk（钉钉）"
            return result
        log(f"开始配置渠道类型：{channel_type}")

        # 1.2 按渠道类型校验对应密钥
        channel_appId = args.get("channel_appId")
        channel_appSecret = args.get("channel_appSecret")
        if not channel_appId or not channel_appSecret:
            result["error"] = f"参数错误：配置{channel_type}渠道必须传入channel_appId和channel_appSecret"
            return result

        # -------------------------- 步骤2：执行配置修改命令 --------------------------
        if channel_type == "feishu":
            # 清除钉钉配置
            clear_dingtalk_cmd = "openclaw config set channels.dingtalk-connector {}"
            clear_dingtalk_result = run_shell_command(clear_dingtalk_cmd)
            result["data"]["commands_executed"].append({
                "command": clear_dingtalk_cmd,
                "success": clear_dingtalk_result["success"],
                "stdout": clear_dingtalk_result["stdout"],
                "stderr": clear_dingtalk_result["stderr"]
            })
            if not clear_dingtalk_result["success"]:
                result["error"] = f"清除钉钉配置失败：{clear_dingtalk_result['stderr']}"
                return result
            result["data"]["config_changes"].append("已清除钉钉连接器配置")

            # 配置飞书appId
            set_appid_cmd = f"openclaw config set channels.feishu.appId '{channel_appId}'"
            appid_result = run_shell_command(set_appid_cmd)
            result["data"]["commands_executed"].append({
                "command": set_appid_cmd,
                "success": appid_result["success"],
                "stdout": appid_result["stdout"],
                "stderr": appid_result["stderr"]
            })
            if not appid_result["success"]:
                result["error"] = f"配置飞书appId失败：{appid_result['stderr']}"
                return result
            result["data"]["config_changes"].append(f"飞书appId已设置（已脱敏：{channel_appId[:8]}****）")

            # 配置飞书appSecret
            set_appsecret_cmd = f"openclaw config set channels.feishu.appSecret '{channel_appSecret}'"
            appsecret_result = run_shell_command(set_appsecret_cmd)
            result["data"]["commands_executed"].append({
                "command": set_appsecret_cmd,
                "success": appsecret_result["success"],
                "stdout": appsecret_result["stdout"],
                "stderr": appsecret_result["stderr"]
            })
            if not appsecret_result["success"]:
                result["error"] = f"配置飞书appSecret失败：{appsecret_result['stderr']}"
                return result
            result["data"]["config_changes"].append(f"飞书appSecret已设置（已脱敏：{channel_appSecret[:8]}****）")

            # 配置飞书dmPolicy
            set_appsecret_cmd = "openclaw config set channels.feishu.dmPolicy open"
            appsecret_result = run_shell_command(set_appsecret_cmd)
            result["data"]["commands_executed"].append({
                "command": set_appsecret_cmd,
                "success": appsecret_result["success"],
                "stdout": appsecret_result["stdout"],
                "stderr": appsecret_result["stderr"]
            })
            if not appsecret_result["success"]:
                result["error"] = f"配置飞书dmPolicy失败：{appsecret_result['stderr']}"
                return result
            result["data"]["config_changes"].append("飞书dmPolicy为open已设置")

            # 配置飞书allowFrom
            set_appsecret_cmd = """openclaw config set channels.feishu.allowFrom '["*"]'"""
            appsecret_result = run_shell_command(set_appsecret_cmd)
            result["data"]["commands_executed"].append({
                "command": set_appsecret_cmd,
                "success": appsecret_result["success"],
                "stdout": appsecret_result["stdout"],
                "stderr": appsecret_result["stderr"]
            })
            if not appsecret_result["success"]:
                result["error"] = f"配置飞书allowFrom失败：{appsecret_result['stderr']}"
                return result
            result["data"]["config_changes"].append('飞书allowFrom为["*"]已设置')
        elif channel_type == "dingtalk":
            # 清除飞书配置
            clear_feishu_cmd = "openclaw config set channels.feishu {}"
            clear_feishu_result = run_shell_command(clear_feishu_cmd)
            result["data"]["commands_executed"].append({
                "command": clear_feishu_cmd,
                "success": clear_feishu_result["success"],
                "stdout": clear_feishu_result["stdout"],
                "stderr": clear_feishu_result["stderr"]
            })
            if not clear_feishu_result["success"]:
                result["error"] = f"清除飞书配置失败：{clear_feishu_result['stderr']}"
                return result
            result["data"]["config_changes"].append("已清除飞书连接器配置")

            # 启用钉钉连接器
            enable_cmd = f"openclaw config set channels.dingtalk-connector.enabled true"
            enable_result = run_shell_command(enable_cmd)
            result["data"]["commands_executed"].append({
                "command": enable_cmd,
                "success": enable_result["success"],
                "stdout": enable_result["stdout"],
                "stderr": enable_result["stderr"]
            })
            if not enable_result["success"]:
                result["error"] = f"配置钉钉clientId失败：{enable_result['stderr']}"
                return result
            result["data"]["config_changes"].append("已启用钉钉连接器")
            # sessionTimeout
            timeout_cmd = f"openclaw config set channels.dingtalk-connector.sessionTimeout 1800000"
            timeout_result = run_shell_command(timeout_cmd)
            result["data"]["commands_executed"].append({
                "command": timeout_cmd,
                "success": timeout_result["success"],
                "stdout": timeout_result["stdout"],
                "stderr": timeout_result["stderr"]
            })
            if not timeout_result["success"]:
                result["error"] = f"配置钉钉sessionTimeout失败：{timeout_result['stderr']}"
                return result
            result["data"]["config_changes"].append("钉钉sessionTimeout已设置为1800000毫秒")

            # 配置钉钉clientId
            set_clientid_cmd = f"openclaw config set channels.dingtalk-connector.clientId '{channel_appId}'"
            clientid_result = run_shell_command(set_clientid_cmd)
            result["data"]["commands_executed"].append({
                "command": set_clientid_cmd,
                "success": clientid_result["success"],
                "stdout": clientid_result["stdout"],
                "stderr": clientid_result["stderr"]
            })
            if not clientid_result["success"]:
                result["error"] = f"配置钉钉clientId失败：{clientid_result['stderr']}"
                return result
            result["data"]["config_changes"].append(f"钉钉clientId已设置（已脱敏：{channel_appId[:8]}****）")

            # 配置钉钉clientSecret
            set_clientsecret_cmd = f"openclaw config set channels.dingtalk-connector.clientSecret '{channel_appSecret}'"
            clientsecret_result = run_shell_command(set_clientsecret_cmd)
            result["data"]["commands_executed"].append({
                "command": set_clientsecret_cmd,
                "success": clientsecret_result["success"],
                "stdout": clientsecret_result["stdout"],
                "stderr": clientsecret_result["stderr"]
            })
            if not clientsecret_result["success"]:
                result["error"] = f"配置钉钉clientSecret失败：{clientsecret_result['stderr']}"
                return result
            result["data"]["config_changes"].append(f"钉钉clientSecret已设置（已脱敏：{channel_appSecret[:8]}****）")
            
            # 获取token
            gateway_token_cmd ="jq -r '.gateway.auth.token' /root/.openclaw/openclaw.json"
            token_result = run_shell_command(gateway_token_cmd)
            result["data"]["commands_executed"].append({
                "command": gateway_token_cmd,
                "success": token_result["success"],
                "stdout": token_result["stdout"],
                "stderr": token_result["stderr"]
            })
            if not token_result["success"]:
                result["error"] = f"获取网关token失败：{token_result['stderr']}"
                return result
            result["data"]["config_changes"].append(f"网关token已获取（已脱敏：{token_result['stdout'][:8]}****）")
            token = token_result["stdout"].strip()

            # 配置钉钉token
            set_token_cmd = f"openclaw config set channels.dingtalk-connector.gatewayToken '{token}'"
            token_result = run_shell_command(set_token_cmd)
            result["data"]["commands_executed"].append({
                "command": set_token_cmd,
                "success": token_result["success"],
                "stdout": token_result["stdout"],
                "stderr": token_result["stderr"]
            })
            if not token_result["success"]:
                result["error"] = f"配置钉钉token失败：{token_result['stderr']}"
                return result
            result["data"]["config_changes"].append(f"钉钉token已设置（已脱敏：{token[:8]}****）")

            # 配置gateway.http.endpoints.chatCompletions.enabled
            set_enabled_cmd = f"openclaw config set gateway.http.endpoints.chatCompletions.enabled true"
            enabled_result = run_shell_command(set_enabled_cmd)
            result["data"]["commands_executed"].append({
                "command": set_enabled_cmd,
                "success": enabled_result["success"],
                "stdout": enabled_result["stdout"],
                "stderr": enabled_result["stderr"]
            })
            if not enabled_result["success"]:
                result["error"] = f"配置gateway.http.endpoints.chatCompletions.enabled失败：{enabled_result['stderr']}"
                return result
            result["data"]["config_changes"].append("已启用gateway.http.endpoints.chatCompletions.enabled")

        # -------------------------- 步骤3：重启网关 --------------------------
        reboot_cmd = "openclaw gateway restart"
        reboot_result = run_shell_command(reboot_cmd)
        result["data"]["commands_executed"].append({
            "command": reboot_cmd,
            "success": reboot_result["success"],
            "stdout": reboot_result["stdout"],
            "stderr": reboot_result["stderr"]
        })
        if reboot_result["success"]:
            result["data"]["restart"] = "网关重启成功，配置已生效"
        else:
            result["data"]["restart"] = f"网关重启失败：{reboot_result['stderr']}"

        # -------------------------- 步骤4：返回成功结果 --------------------------
        result["success"] = True
        result["error"] = None

    except Exception as e:
        # 捕获所有异常，返回详细信息
        error_msg = f"渠道配置异常：{str(e)}"
        result["error"] = error_msg
        result["data"]["error_detail"] = traceback.format_exc()[:500]  # 限制异常详情长度

    return result


if __name__ == "__main__":
    # 命令行参数调用示例：
    # 飞书：python message_channel_mod.py feishu "appId值" "appSecret值" "" ""
    # 钉钉：python message_channel_mod.py dingtalk "" "" "clientId值" "clientSecret值"
    if len(sys.argv) != 4:
        print("用法：")
        print("飞书配置：python message_channel_mod.py feishu [feishu_appId] [feishu_appSecret]")
        print("钉钉配置：python message_channel_mod.py dingtalk [dingtalk_clientId] [dingtalk_clientSecret]")
        sys.exit(1)

    # 解析命令行参数
    args = {
        "channel_type": sys.argv[1],
        "channel_appId": sys.argv[2],
        "channel_appSecret": sys.argv[3],
    }
    # 执行配置逻辑并输出结果
    log(f"传入参数：{args}")
    config_result = handler(args)
    print(json.dumps(config_result, ensure_ascii=False, indent=2))