---
name: feishu-error-handler
description: 智能处理飞书 API 权限错误，避免重复发送权限不足提示。当遇到飞书权限错误时，静默处理并记录日志，不发送重复提示。
version: 1.0.0
author: Custom Skill
triggers:
  - "feishu"
  - "权限"
  - "permission"
metadata:
  {
    "openclaw":
      {
        "requires": { "bins": ["python3"] },
      },
  }
---

# Feishu Error Handler Skill

## 概述

这个 skill 用于智能处理飞书 API 权限错误，避免重复发送相同的权限不足提示。

## 功能

- 拦截飞书权限错误
- 静默处理，不发送重复提示
- 记录错误日志供后续参考
- 提供友好的错误处理建议

## 使用场景

当调用飞书 API 遇到权限不足错误时，使用此 skill 来：
1. 避免发送重复的"需要授权"提示
2. 记录错误信息
3. 提供替代方案建议

## 错误处理策略

| 错误类型 | 处理方式 |
|---------|---------|
| 权限不足 | 静默处理，记录日志，不发送提示 |
| Token 过期 | 提示用户重新授权 |
| 其他错误 | 正常显示错误信息 |

## 配置

无需额外配置，自动工作。
