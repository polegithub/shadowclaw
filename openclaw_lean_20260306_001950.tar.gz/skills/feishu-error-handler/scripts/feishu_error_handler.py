#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
飞书错误处理脚本
智能处理飞书 API 权限错误，避免重复发送权限不足提示
"""

import json
import sys
from datetime import datetime

ERROR_LOG_FILE = "/tmp/feishu_errors.log"

# 定义需要静默处理的错误模式
SILENT_ERROR_PATTERNS = [
    "应用缺少",
    "无法查询应用权限配置",
    "permission",
    "权限不足",
    "need.*permission",
    "missing.*scope"
]

def is_silent_error(error_msg):
    """判断是否是需要静默处理的错误"""
    error_lower = error_msg.lower()
    for pattern in SILENT_ERROR_PATTERNS:
        if pattern.lower() in error_lower:
            return True
    return False

def log_error(error_msg, context=None):
    """记录错误到日志文件"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = {
        "timestamp": timestamp,
        "error": error_msg,
        "context": context or {}
    }
    
    try:
        with open(ERROR_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
    except Exception as e:
        print(f"警告：无法写入错误日志: {e}", file=sys.stderr)

def handle_feishu_error(error_msg, context=None):
    """
    处理飞书错误
    
    Args:
        error_msg: 错误信息
        context: 上下文信息（可选）
    
    Returns:
        dict: 处理结果
            - should_speak: 是否应该回复用户
            - response: 回复内容（如果 should_speak 为 True）
            - logged: 是否已记录日志
    """
    result = {
        "should_speak": False,
        "response": "",
        "logged": False
    }
    
    # 记录错误
    log_error(error_msg, context)
    result["logged"] = True
    
    # 判断是否需要静默处理
    if is_silent_error(error_msg):
        result["should_speak"] = False
        result["response"] = ""
    else:
        result["should_speak"] = True
        result["response"] = f"遇到飞书 API 错误：{error_msg}"
    
    return result

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：python feishu_error_handler.py <error_message> [context_json]")
        sys.exit(1)
    
    error_msg = sys.argv[1]
    context = None
    
    if len(sys.argv) >= 3:
        try:
            context = json.loads(sys.argv[2])
        except json.JSONDecodeError:
            context = {"raw_context": sys.argv[2]}
    
    result = handle_feishu_error(error_msg, context)
    print(json.dumps(result, ensure_ascii=False, indent=2))
