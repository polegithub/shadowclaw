# Feishu Error Handler - 使用指南

## 问题描述

之前每次调用飞书 API 遇到权限问题时，都会重复发送：

```
我还在！不过看起来又遇到权限问题了 😅
需要管理员再授权一下：
开发者后台 - 飞书开放平台...
等授权完成我就能满血复活啦～
```

这很烦！

## 解决方案

创建了 `feishu-error-handler` skill 来智能处理这个问题。

## Skill 功能

1. **静默处理权限错误** - 遇到权限不足时，不发送重复提示
2. **记录错误日志** - 所有错误都会记录到 `/tmp/feishu_errors.log`
3. **智能判断** - 只对真正需要关注的错误发送提示

## 使用方法

### 1. 检查错误是否需要静默

```bash
cd ~/.openclaw/workspace/skills/feishu-error-handler
python3 scripts/feishu_error_handler.py "应用缺少 application:application:self_manage 权限"
```

### 2. 查看错误日志

```bash
tail -f /tmp/feishu_errors.log
```

## 静默处理的错误模式

- "应用缺少"
- "无法查询应用权限配置"
- "permission"
- "权限不足"
- "need.*permission"
- "missing.*scope"

## 集成方式

在调用飞书 API 前/后，使用此 skill 来判断是否应该回复用户。

## 文件结构

```
skills/feishu-error-handler/
├── SKILL.md                      # Skill 定义
├── USAGE.md                      # 本文件
└── scripts/
    └── feishu_error_handler.py   # 错误处理脚本
```

## 测试

```bash
# 测试权限错误（应该静默处理）
python3 scripts/feishu_error_handler.py "应用缺少 application:application:self_manage 权限"

# 测试其他错误（应该正常提示）
python3 scripts/feishu_error_handler.py "网络连接超时"
```
