---
name: openclaw-snapshot
description: OpenClaw 完整快照备份与恢复工具。支持配置备份、会话备份、技能备份、一键恢复到任意时间点。防止电脑重启、恢复出厂设置后丢失配置和记忆。
version: 1.0.0
author: Custom Skill
triggers:
  - "backup"
  - "snapshot"
  - "恢复"
  - "备份"
metadata:
  {
    "openclaw":
      {
        "requires": { "bins": ["tar", "gzip", "jq"] },
      },
  }
---

# OpenClaw Snapshot Skill

## 概述

提供 OpenClaw 完整快照备份与恢复功能，防止数据丢失。

## 功能

- ✅ 完整配置备份（~/.openclaw）
- ✅ 会话历史备份
- ✅ Skills 备份
- ✅ 增量快照
- ✅ 一键恢复到任意时间点
- ✅ 自动定时备份
- ✅ 快照列表查看
- ✅ 快照导出/导入

## 快速开始

### 创建快照

```bash
cd ~/.openclaw/workspace/skills/openclaw-snapshot
./scripts/snapshot.sh create
```

### 查看快照列表

```bash
./scripts/snapshot.sh list
```

### 恢复快照

```bash
./scripts/snapshot.sh restore <snapshot_name>
```

### 定时备份（每天凌晨 2 点）

```bash
./scripts/snapshot.sh schedule
```

## 快照内容

| 目录 | 说明 |
|------|------|
| `~/.openclaw/config/` | 配置文件 |
| `~/.openclaw/agents/` | Agent 会话和记忆 |
| `~/.openclaw/workspace/skills/` | 自定义 Skills |
| `~/.openclaw/extensions/` | 插件配置 |

## 文件位置

- 快照存储：`~/.openclaw/snapshots/`
- 脚本目录：`~/.openclaw/workspace/skills/openclaw-snapshot/scripts/`
