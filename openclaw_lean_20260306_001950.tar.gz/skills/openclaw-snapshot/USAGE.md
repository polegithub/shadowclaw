# OpenClaw Snapshot - 使用指南

## 📦 功能概览

这个 skill 提供完整的 OpenClaw 备份与恢复解决方案，防止数据丢失。

## 🚀 快速开始

### 1. 创建第一个快照

```bash
cd ~/.openclaw/workspace/skills/openclaw-snapshot
./scripts/snapshot.sh create
```

### 2. 查看可用快照

```bash
./scripts/snapshot.sh list
```

### 3. 恢复快照

```bash
./scripts/snapshot.sh restore <snapshot_name>
```

### 4. 设置定时备份（推荐）

```bash
./scripts/snapshot.sh schedule
```
这会在每天凌晨 2 点自动创建快照。

---

## 📋 完整命令列表

| 命令 | 说明 | 示例 |
|------|------|------|
| `create [name]` | 创建快照 | `./snapshot.sh create` 或 `./snapshot.sh create my_backup` |
| `list` | 列出快照 | `./snapshot.sh list` |
| `restore <name>` | 恢复快照 | `./snapshot.sh restore openclaw_host_20260305_234500` |
| `delete <name>` | 删除快照 | `./snapshot.sh delete old_backup` |
| `schedule` | 设置定时备份 | `./snapshot.sh schedule` |
| `help` | 显示帮助 | `./snapshot.sh help` |

---

## 💾 快照包含的内容

| 目录 | 说明 |
|------|------|
| `~/.openclaw/config/` | OpenClaw 配置文件 |
| `~/.openclaw/agents/` | Agent 会话和记忆（MEMORY.md、聊天记录等） |
| `~/.openclaw/workspace/skills/` | 自定义 Skills |
| `~/.openclaw/extensions/` | 插件配置 |

---

## 🎯 使用场景

### 场景 1：电脑重启前

```bash
# 创建快照
./scripts/snapshot.sh create pre_reboot

# 重启后如果需要恢复
./scripts/snapshot.sh restore pre_reboot
```

### 场景 2：恢复出厂设置后

```bash
# 假设你把快照保存到了 U 盘或云端
# 复制快照回来后：
./scripts/snapshot.sh restore my_safe_backup
```

### 场景 3：每天自动备份

```bash
# 设置定时备份
./scripts/snapshot.sh schedule

# 之后就不用管了，每天凌晨 2 点自动备份
```

---

## 📁 文件位置

| 项目 | 路径 |
|------|------|
| 快照存储 | `~/.openclaw/snapshots/` |
| Skill 目录 | `~/.openclaw/workspace/skills/openclaw-snapshot/` |
| 主脚本 | `~/.openclaw/workspace/skills/openclaw-snapshot/scripts/snapshot.sh` |

---

## 🔒 安全建议

1. **定期创建快照** - 至少每周一次，或在重大变更前
2. **异地备份** - 把快照文件复制到 U 盘、云端或其他机器
3. **测试恢复** - 偶尔测试一下快照是否能正常恢复
4. **保留多个版本** - 保留最近几个快照，不要只留一个

---

## ⚠️ 注意事项

- 恢复快照会**覆盖**当前的配置和数据，操作前会自动创建一个备份
- 大的快照可能需要较长时间创建和恢复
- 定时备份需要系统支持 cron（Linux/macOS）

---

## 🆘 故障排除

### 问题：没有权限执行脚本
```bash
chmod +x ~/.openclaw/workspace/skills/openclaw-snapshot/scripts/snapshot.sh
```

### 问题：快照目录不存在
脚本会自动创建，不用担心。

### 问题：恢复后数据不对
恢复前会自动创建 `pre_restore_backup_*` 快照，可以恢复那个。
