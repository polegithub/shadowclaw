#!/bin/bash
# OpenClaw Snapshot Manager
# 完整的 OpenClaw 快照备份与恢复工具

set -e

SNAPSHOT_DIR="$HOME/.openclaw/snapshots"
OPENCLAW_DIR="$HOME/.openclaw"
WORKSPACE_DIR="$HOME/.openclaw/workspace"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
HOSTNAME=$(hostname)

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 初始化快照目录
init_snapshot_dir() {
    if [ ! -d "$SNAPSHOT_DIR" ]; then
        mkdir -p "$SNAPSHOT_DIR"
        log_info "创建快照目录: $SNAPSHOT_DIR"
    fi
}

# 创建快照
create_snapshot() {
    local snapshot_name="$1"
    if [ -z "$snapshot_name" ]; then
        snapshot_name="openclaw_${HOSTNAME}_${TIMESTAMP}"
    fi

    local snapshot_path="$SNAPSHOT_DIR/$snapshot_name"
    local snapshot_tar="$snapshot_path.tar.gz"

    log_info "开始创建快照: $snapshot_name"

    # 创建临时目录
    local temp_dir=$(mktemp -d)
    log_info "临时目录: $temp_dir"

    # 复制需要备份的内容
    log_info "复制配置文件..."
    if [ -d "$OPENCLAW_DIR/config" ]; then
        cp -r "$OPENCLAW_DIR/config" "$temp_dir/" 2>/dev/null || true
    fi

    log_info "复制 Agents 会话..."
    if [ -d "$OPENCLAW_DIR/agents" ]; then
        cp -r "$OPENCLAW_DIR/agents" "$temp_dir/" 2>/dev/null || true
    fi

    log_info "复制 Workspace Skills..."
    if [ -d "$WORKSPACE_DIR/skills" ]; then
        cp -r "$WORKSPACE_DIR/skills" "$temp_dir/" 2>/dev/null || true
    fi

    log_info "复制 Extensions..."
    if [ -d "$OPENCLAW_DIR/extensions" ]; then
        cp -r "$OPENCLAW_DIR/extensions" "$temp_dir/" 2>/dev/null || true
    fi

    # 创建快照信息文件
    cat > "$temp_dir/snapshot_info.json" <<EOF
{
  "name": "$snapshot_name",
  "timestamp": "$(date -Iseconds)",
  "hostname": "$HOSTNAME",
  "version": "1.0.0",
  "description": "OpenClaw full snapshot"
}
EOF

    # 创建压缩包
    log_info "创建压缩包..."
    tar -czf "$snapshot_tar" -C "$temp_dir" . 2>/dev/null

    # 清理临时目录
    rm -rf "$temp_dir"

    # 计算快照大小
    local snapshot_size=$(du -h "$snapshot_tar" | cut -f1)

    log_success "快照创建完成！"
    echo "  名称: $snapshot_name"
    echo "  位置: $snapshot_tar"
    echo "  大小: $snapshot_size"
    echo ""
    echo "恢复命令:"
    echo "  ./scripts/snapshot.sh restore $snapshot_name"
}

# 列出快照
list_snapshots() {
    log_info "可用快照列表:"
    echo ""

    if [ ! -d "$SNAPSHOT_DIR" ] || [ -z "$(ls -A "$SNAPSHOT_DIR" 2>/dev/null)" ]; then
        log_warning "没有找到快照"
        echo "使用 './scripts/snapshot.sh create' 创建快照"
        return
    fi

    echo "┌──────────────────────────────────┬──────────────────────┬──────────┐"
    echo "│ 快照名称                         │ 创建时间             │ 大小     │"
    echo "├──────────────────────────────────┼──────────────────────┼──────────┤"

    for snapshot_file in "$SNAPSHOT_DIR"/*.tar.gz; do
        if [ -f "$snapshot_file" ]; then
            local snapshot_name=$(basename "$snapshot_file" .tar.gz)
            local snapshot_size=$(du -h "$snapshot_file" | cut -f1)
            local snapshot_mtime=$(stat -c %y "$snapshot_file" | cut -d'.' -f1)

            printf "│ %-32s │ %-20s │ %-8s │\n" \
                "$snapshot_name" \
                "$snapshot_mtime" \
                "$snapshot_size"
        fi
    done

    echo "└──────────────────────────────────┴──────────────────────┴──────────┘"
    echo ""
    echo "恢复命令示例:"
    echo "  ./scripts/snapshot.sh restore <snapshot_name>"
}

# 恢复快照
restore_snapshot() {
    local snapshot_name="$1"

    if [ -z "$snapshot_name" ]; then
        log_error "请指定要恢复的快照名称"
        echo "使用 './scripts/snapshot.sh list' 查看可用快照"
        return 1
    fi

    local snapshot_tar="$SNAPSHOT_DIR/$snapshot_name.tar.gz"

    if [ ! -f "$snapshot_tar" ]; then
        log_error "快照不存在: $snapshot_name"
        return 1
    fi

    log_warning "准备恢复快照: $snapshot_name"
    log_warning "这将覆盖当前的配置和数据！"
    echo ""
    read -p "确认继续？(yes/NO): " confirm

    if [ "$confirm" != "yes" ] && [ "$confirm" != "YES" ]; then
        log_info "操作已取消"
        return
    fi

    # 创建当前状态的备份（以防万一）
    local backup_name="pre_restore_backup_${TIMESTAMP}"
    log_info "创建当前状态备份: $backup_name"
    create_snapshot "$backup_name" > /dev/null 2>&1

    # 解压快照
    log_info "解压快照..."
    local temp_dir=$(mktemp -d)
    tar -xzf "$snapshot_tar" -C "$temp_dir"

    # 显示快照信息
    if [ -f "$temp_dir/snapshot_info.json" ]; then
        log_info "快照信息:"
        cat "$temp_dir/snapshot_info.json" | jq .
    fi

    # 恢复文件
    log_info "恢复配置文件..."
    if [ -d "$temp_dir/config" ]; then
        rm -rf "$OPENCLAW_DIR/config"
        cp -r "$temp_dir/config" "$OPENCLAW_DIR/"
    fi

    log_info "恢复 Agents 会话..."
    if [ -d "$temp_dir/agents" ]; then
        rm -rf "$OPENCLAW_DIR/agents"
        cp -r "$temp_dir/agents" "$OPENCLAW_DIR/"
    fi

    log_info "恢复 Skills..."
    if [ -d "$temp_dir/skills" ]; then
        rm -rf "$WORKSPACE_DIR/skills"
        cp -r "$temp_dir/skills" "$WORKSPACE_DIR/"
    fi

    log_info "恢复 Extensions..."
    if [ -d "$temp_dir/extensions" ]; then
        rm -rf "$OPENCLAW_DIR/extensions"
        cp -r "$temp_dir/extensions" "$OPENCLAW_DIR/"
    fi

    # 清理
    rm -rf "$temp_dir"

    log_success "快照恢复完成！"
    echo ""
    echo "建议重启 OpenClaw Gateway:"
    echo "  openclaw gateway restart"
}

# 删除快照
delete_snapshot() {
    local snapshot_name="$1"

    if [ -z "$snapshot_name" ]; then
        log_error "请指定要删除的快照名称"
        return 1
    fi

    local snapshot_tar="$SNAPSHOT_DIR/$snapshot_name.tar.gz"

    if [ ! -f "$snapshot_tar" ]; then
        log_error "快照不存在: $snapshot_name"
        return 1
    fi

    log_warning "准备删除快照: $snapshot_name"
    echo ""
    read -p "确认删除？(yes/NO): " confirm

    if [ "$confirm" != "yes" ] && [ "$confirm" != "YES" ]; then
        log_info "操作已取消"
        return
    fi

    rm "$snapshot_tar"
    log_success "快照已删除: $snapshot_name"
}

# 设置定时备份
setup_cron() {
    local cron_job="0 2 * * * cd $HOME/.openclaw/workspace/skills/openclaw-snapshot && ./scripts/snapshot.sh create auto_daily >> $SNAPSHOT_DIR/cron.log 2>&1"

    log_info "设置定时备份（每天凌晨 2 点）"

    # 检查是否已存在
    if crontab -l 2>/dev/null | grep -q "snapshot.sh create"; then
        log_warning "定时备份已存在"
        echo "当前 cron 任务:"
        crontab -l | grep "snapshot.sh"
        return
    fi

    # 添加 cron 任务
    (crontab -l 2>/dev/null; echo "$cron_job") | crontab -

    log_success "定时备份已设置"
    echo "Cron 任务: $cron_job"
}

# 显示帮助
show_help() {
    echo "OpenClaw Snapshot Manager v1.0.0"
    echo ""
    echo "用法: ./scripts/snapshot.sh [命令] [参数]"
    echo ""
    echo "命令:"
    echo "  create [name]   - 创建快照（可选指定名称）"
    echo "  list            - 列出所有快照"
    echo "  restore <name>  - 恢复指定快照"
    echo "  delete <name>   - 删除指定快照"
    echo "  schedule        - 设置定时备份（每天凌晨2点）"
    echo "  help            - 显示此帮助"
    echo ""
    echo "示例:"
    echo "  ./scripts/snapshot.sh create"
    echo "  ./scripts/snapshot.sh create my_backup"
    echo "  ./scripts/snapshot.sh list"
    echo "  ./scripts/snapshot.sh restore openclaw_host_20260305_234500"
    echo "  ./scripts/snapshot.sh schedule"
}

# 主函数
main() {
    init_snapshot_dir

    case "${1:-help}" in
        create)
            create_snapshot "$2"
            ;;
        list)
            list_snapshots
            ;;
        restore)
            restore_snapshot "$2"
            ;;
        delete)
            delete_snapshot "$2"
            ;;
        schedule)
            setup_cron
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            log_error "未知命令: $1"
            show_help
            exit 1
            ;;
    esac
}

main "$@"
