#!/bin/bash
# OpenClaw 快照云端备份脚本
# 支持 GitHub、Gitee、等 Git 仓库备份

set -e

SNAPSHOT_DIR="$HOME/.openclaw/snapshots"
BACKUP_REPO_DIR="$HOME/.openclaw/snapshot-backup"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查 Git 是否安装
check_git() {
    if ! command -v git &> /dev/null; then
        log_error "Git 未安装，请先安装 Git"
        echo "Ubuntu/Debian: sudo apt-get install git"
        echo "CentOS/RHEL: sudo yum install git"
        echo "macOS: brew install git"
        return 1
    fi
}

# 初始化备份仓库
init_backup_repo() {
    local repo_url="$1"

    if [ -z "$repo_url" ]; then
        log_error "请提供 Git 仓库 URL"
        echo "示例: ./cloud-backup.sh init git@github.com:username/openclaw-backups.git"
        return 1
    fi

    if [ -d "$BACKUP_REPO_DIR" ]; then
        log_warning "备份目录已存在，删除后重新初始化..."
        rm -rf "$BACKUP_REPO_DIR"
    fi

    log_info "克隆备份仓库: $repo_url"
    git clone "$repo_url" "$BACKUP_REPO_DIR"

    log_success "备份仓库初始化完成"
    echo "仓库位置: $BACKUP_REPO_DIR"
}

# 备份快照到云端
backup_to_cloud() {
    if [ ! -d "$BACKUP_REPO_DIR" ]; then
        log_error "备份仓库未初始化"
        echo "请先运行: ./cloud-backup.sh init <repo_url>"
        return 1
    fi

    if [ ! -d "$SNAPSHOT_DIR" ] || [ -z "$(ls -A "$SNAPSHOT_DIR" 2>/dev/null)" ]; then
        log_warning "没有找到快照，先创建一个..."
        cd "$HOME/.openclaw/workspace/skills/openclaw-snapshot"
        ./scripts/quick-snapshot.sh
    fi

    log_info "复制快照到备份仓库..."
    cp "$SNAPSHOT_DIR"/*.tar.gz "$BACKUP_REPO_DIR/" 2>/dev/null || true

    # 创建 README
    cat > "$BACKUP_REPO_DIR/README.md" <<EOF
# OpenClaw Snapshots

自动备份的 OpenClaw 快照。

## 快照列表

EOF

    cd "$BACKUP_REPO_DIR"

    # 生成快照列表
    for snapshot in *.tar.gz; do
        if [ -f "$snapshot" ]; then
            local snapshot_size=$(du -h "$snapshot" | cut -f1)
            local snapshot_mtime=$(stat -c %y "$snapshot" 2>/dev/null || stat -f %Sm -t "%Y-%m-%d %H:%M:%S" "$snapshot" 2>/dev/null || date -r "$snapshot" "+%Y-%m-%d %H:%M:%S" 2>/dev/null || "unknown")
            echo "- \`$snapshot\` ($snapshot_size) - $snapshot_mtime" >> README.md
        fi
    done

    # Git 提交
    log_info "提交到 Git..."
    git add .
    git commit -m "Update snapshots: $TIMESTAMP" 2>/dev/null || {
        log_warning "没有新的快照需要提交"
        return 0
    }

    log_info "推送到远程仓库..."
    git push

    log_success "快照已备份到云端！"
}

# 从云端恢复
restore_from_cloud() {
    if [ ! -d "$BACKUP_REPO_DIR" ]; then
        log_error "备份仓库未初始化"
        return 1
    fi

    log_info "从云端拉取最新快照..."
    cd "$BACKUP_REPO_DIR"
    git pull

    log_info "可用快照:"
    ls -lh "$BACKUP_REPO_DIR"/*.tar.gz 2>/dev/null || echo "没有找到快照"

    echo ""
    read -p "输入要恢复的快照文件名: " snapshot_name

    if [ ! -f "$BACKUP_REPO_DIR/$snapshot_name" ]; then
        log_error "快照不存在: $snapshot_name"
        return 1
    fi

    # 复制到快照目录
    cp "$BACKUP_REPO_DIR/$snapshot_name" "$SNAPSHOT_DIR/"

    log_success "快照已复制到本地: $snapshot_name"
    echo ""
    echo "现在可以运行恢复命令:"
    echo "  cd ~/.openclaw/workspace/skills/openclaw-snapshot"
    echo "  ./scripts/snapshot.sh restore $(basename "$snapshot_name" .tar.gz)"
}

# 显示帮助
show_help() {
    echo "OpenClaw 云端备份工具 v1.0.0"
    echo ""
    echo "用法: ./cloud-backup.sh [命令] [参数]"
    echo ""
    echo "命令:"
    echo "  init <repo_url>   - 初始化备份仓库（GitHub/Gitee 等）"
    echo "  backup            - 备份快照到云端"
    echo "  restore           - 从云端恢复快照"
    echo "  help              - 显示此帮助"
    echo ""
    echo "示例:"
    echo "  ./cloud-backup.sh init git@github.com:username/openclaw-backups.git"
    echo "  ./cloud-backup.sh backup"
    echo "  ./cloud-backup.sh restore"
    echo ""
    echo "设置步骤:"
    echo "  1. 在 GitHub 创建私有仓库: openclaw-backups"
    echo "  2. 运行 init 命令初始化"
    echo "  3. 运行 backup 命令备份"
}

# 主函数
main() {
    check_git || return 1

    case "${1:-help}" in
        init)
            init_backup_repo "$2"
            ;;
        backup)
            backup_to_cloud
            ;;
        restore)
            restore_from_cloud
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            log_error "未知命令: $1"
            show_help
            exit 1
            ;;
    esac
}

main "$@"
