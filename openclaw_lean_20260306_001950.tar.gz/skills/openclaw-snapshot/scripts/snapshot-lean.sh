#!/bin/bash
# 优化版 OpenClaw 快照脚本 - 排除大文件和不必要的内容

SNAPSHOT_DIR="$HOME/.openclaw/snapshots"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
SNAPSHOT_NAME="openclaw_lean_$TIMESTAMP"
SNAPSHOT_FILE="$SNAPSHOT_DIR/$SNAPSHOT_NAME.tar.gz"

echo "🚀 创建优化版快照: $SNAPSHOT_NAME"
echo ""

# 创建临时目录
TMP_DIR=$(mktemp -d)
echo "临时目录: $TMP_DIR"

# 复制关键内容（排除大文件）
echo ""
echo "📋 复制配置文件..."
[ -d "$HOME/.openclaw/config" ] && cp -r "$HOME/.openclaw/config" "$TMP_DIR/" 2>/dev/null

echo "📋 复制 Agents（会话和记忆）..."
[ -d "$HOME/.openclaw/agents" ] && cp -r "$HOME/.openclaw/agents" "$TMP_DIR/" 2>/dev/null

echo "📋 复制自定义 Skills..."
[ -d "$HOME/.openclaw/workspace/skills" ] && cp -r "$HOME/.openclaw/workspace/skills" "$TMP_DIR/" 2>/dev/null

echo "📋 复制 chat_ids.md..."
[ -f "$HOME/.openclaw/workspace/chat_ids.md" ] && cp "$HOME/.openclaw/workspace/chat_ids.md" "$TMP_DIR/" 2>/dev/null

# 创建排除列表（不备份的内容）
cat > "$TMP_DIR/EXCLUDED.md" <<EOF
# 未备份的内容（不需要）

以下内容太大或可以重新安装，不包含在快照中：

- extensions/qqbot (1.4GB) - 可以重新安装
- extensions/dingtalk-connector (83MB) - 可以重新安装
- extensions/feishu-openclaw-plugin (55MB) - 可以重新安装
- extensions/wecom (1.9MB) - 可以重新安装
- extensions/ai-assistant-security-openclaw (88KB) - 可以重新安装
- node_modules/ - 可以重新安装
- logs/ - 临时日志

需要恢复时，重新安装扩展即可！
EOF

# 创建快照信息
cat > "$TMP_DIR/snapshot_info.json" <<EOF
{
  "name": "$SNAPSHOT_NAME",
  "type": "lean",
  "timestamp": "$(date -Iseconds)",
  "version": "2.0.0",
  "description": "Optimized snapshot (excludes large extensions)"
}
EOF

# 显示将要备份的内容
echo ""
echo "📦 将要备份的内容："
cd "$TMP_DIR" && du -sh * 2>/dev/null

echo ""
echo "🗜️ 创建压缩包..."
tar -czf "$SNAPSHOT_FILE" -C "$TMP_DIR" . 2>&1

# 清理
rm -rf "$TMP_DIR"

# 完成
if [ -f "$SNAPSHOT_FILE" ]; then
    SIZE=$(du -h "$SNAPSHOT_FILE" | cut -f1)
    echo ""
    echo "✅ 优化版快照创建成功！"
    echo "  名称: $SNAPSHOT_NAME"
    echo "  位置: $SNAPSHOT_FILE"
    echo "  大小: $SIZE"
    echo ""
    echo "对比："
    echo "  完整版: 523 MB"
    echo "  优化版: $SIZE"
    echo ""
    echo "说明：extensions 目录已排除，需要时重新安装即可！"
else
    echo "❌ 快照创建失败"
    exit 1
fi
