#!/bin/bash
# 快速创建 OpenClaw 快照

SNAPSHOT_DIR="$HOME/.openclaw/snapshots"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
SNAPSHOT_NAME="openclaw_snapshot_$TIMESTAMP"
SNAPSHOT_FILE="$SNAPSHOT_DIR/$SNAPSHOT_NAME.tar.gz"

echo "开始创建快照: $SNAPSHOT_NAME"

# 创建快照目录
mkdir -p "$SNAPSHOT_DIR"

# 创建临时目录
TMP_DIR=$(mktemp -d)
echo "临时目录: $TMP_DIR"

# 复制关键内容
echo "复制配置..."
[ -d "$HOME/.openclaw/config" ] && cp -r "$HOME/.openclaw/config" "$TMP_DIR/" 2>/dev/null

echo "复制 Agents..."
[ -d "$HOME/.openclaw/agents" ] && cp -r "$HOME/.openclaw/agents" "$TMP_DIR/" 2>/dev/null

echo "复制 Skills..."
[ -d "$HOME/.openclaw/workspace/skills" ] && cp -r "$HOME/.openclaw/workspace/skills" "$TMP_DIR/" 2>/dev/null

echo "复制 Extensions..."
[ -d "$HOME/.openclaw/extensions" ] && cp -r "$HOME/.openclaw/extensions" "$TMP_DIR/" 2>/dev/null

# 创建快照信息
cat > "$TMP_DIR/snapshot_info.json" <<EOF
{
  "name": "$SNAPSHOT_NAME",
  "timestamp": "$(date -Iseconds)",
  "version": "1.0.0"
}
EOF

# 压缩
echo "创建压缩包..."
tar -czf "$SNAPSHOT_FILE" -C "$TMP_DIR" . 2>&1 | head -20

# 清理
rm -rf "$TMP_DIR"

# 完成
if [ -f "$SNAPSHOT_FILE" ]; then
    SIZE=$(du -h "$SNAPSHOT_FILE" | cut -f1)
    echo ""
    echo "✅ 快照创建成功！"
    echo "  名称: $SNAPSHOT_NAME"
    echo "  位置: $SNAPSHOT_FILE"
    echo "  大小: $SIZE"
else
    echo "❌ 快照创建失败"
    exit 1
fi
